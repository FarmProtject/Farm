using UnityEngine;
using System;
using System.Collections.Generic;
public interface IDayTickable 
{
    void DayPassed();
}
