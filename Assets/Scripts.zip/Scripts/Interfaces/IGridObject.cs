using UnityEngine;
using System;
using System.Collections.Generic;
public interface IGridObject
{

    Vector3 GetGridPosition();

}
