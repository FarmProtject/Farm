using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EquipPanel : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
