using UnityEngine;
using System;
using System.Collections.Generic;
public class ShopPopUpCountText : UIBase
{

}
