using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainInput : InputBase
{
    
    public override void OnPlayerInput()
    {
        throw new System.NotImplementedException();
    }
}
