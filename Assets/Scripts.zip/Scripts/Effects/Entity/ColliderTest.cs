using UnityEngine;
using System;
using System.Collections.Generic;
public class ColliderTest : MonoBehaviour
{
    private void Update()
    {
        this.transform.position = new Vector3(0, 0, 0);
    }
}
