using UnityEngine;
using System;
using System.Collections.Generic;
enum EffectType
{
    none,
    damage,
    heal,
    statBuff
}
public class EffectManager : MonoBehaviour
{
    
}
